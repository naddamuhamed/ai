Theseus Version 1.0
by Heiko Nolte, written February 2010
===============================================

This code is distributed under GNU GENERAL PUBLIC LICENSE, Version 3.

To use install Python 2.x and PyGame API.

Implementation of a random maze generation algorithm
with pygame frontend to visualize it. Also implements
the Lee algorithm to find the shortest way between to
points in the maze.



